/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */
//package creditcardvault;

package Managers;
import Encryptions.*;
import Utilities.*;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.ArrayList;
import java.util.logging.*;
import javax.crypto.SecretKey;


public class CardManager {
    
    private User currentUser;
    
    public CardManager(User user){
        this.currentUser=user;
    }
    
    public void addCard(String cardholder, String type, String cardNumber, UsefulDate expirationDate, int cvv){
        
        CreditCard newCard=new CreditCard(cardholder, type, cardNumber, expirationDate, cvv);//card to be added to user's cards file
        
        //get user's secret key from file (has been encrypted with app's public)
        SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());
        
        //encrypt and store new card to file
        byte[] symmetricallyEncryptedCard=SymmetricKeyFactory.encrypt(newCard, decryptedKey);
        storeCard(symmetricallyEncryptedCard);
    }
    
    public void displayCards(){
        
        ArrayList<byte[]> storedCards=readAllCards();//temp card storage(encrypted)
        
        PrivateKey privateKey=KeyHandler.getAppPrivateKey();
        ArrayList<CreditCard> decryptedCards=new ArrayList<CreditCard>();//temp storage for decrypted cards
        
        for(byte[] card:storedCards){//for each encrypted card -> decrypt -> add to decrypted storage
            decryptedCards.add((CreditCard)AsymmetricKeyFactory.decryptWithPrivate(card, privateKey));
        }
        
        System.out.println(decryptedCards);
        
    }
    
    public void editCard(CreditCard oldCard, int fieldToEdit, Object newValue){
        
        CreditCard updatedCard=new CreditCard(oldCard);
        
        if(fieldToEdit==1){
            updatedCard.setCardholder((String)newValue);
        }else if(fieldToEdit==2){
            updatedCard.setType((String)newValue);
        }else if(fieldToEdit==3){
            updatedCard.setCardNumber((String)newValue);
        }else if(fieldToEdit==4){
            updatedCard.setExpirationDate((UsefulDate)newValue);
        }else if(fieldToEdit==5){
            updatedCard.setCVV((int)newValue);
        }
        
        //get user's secret key from file (has been encrypted with app's public)
        SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());
        
        //encrypt and store updated card to file
        byte[] symmetricallyEncryptedOldCard=SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt old card
        byte[] symmetricallyEncryptedUpdatedCard=SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt new card
        updateStorage(symmetricallyEncryptedOldCard, symmetricallyEncryptedUpdatedCard);//search in file if card already exists and update file accordingly
        
    }
    
    public void deleteCard(CreditCard card){
        
        //get user's secret key from file (has been encrypted with app's public)
        SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());
        
        //encrypt, remove and update file
        byte[] symmetricallyEncryptedCard=SymmetricKeyFactory.encrypt(card, decryptedKey);
        updateStorage(symmetricallyEncryptedCard, null);//search in file if card already exists and update file accordingly
        
    }
    
    private ArrayList<byte[]> readAllCards(){
        
        ArrayList<byte[]> storedCards=new ArrayList<byte[]>();
        
        try{
            
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(currentUser.getUsername()+"/cardVault.dat"));//user's subfolder + filename
            
            byte[] encryptedCard=(byte[])ois.readObject();
            
            if(encryptedCard!=null){//ensure null won't be added to arraylist
                storedCards.add(encryptedCard);
            }
            
            while (encryptedCard!=null){//while there is something to read, keep reading
                try {
                    encryptedCard=(byte[])ois.readObject();
                    if(encryptedCard!=null){//ensure null won't be added to arraylist
                        storedCards.add(encryptedCard);
                    }
                }catch (EOFException ex){
                    System.out.println("eof");
                }
            }
            
            return storedCards;//return results

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    private void updateStorage(byte[] oldCard, byte[] newCard){
        //old card + new card = edit mode
        //null + new card = append mode
        //old card + null = delete mode
        
        ArrayList<byte[]> storedCards=readAllCards();
        
        if(storedCards!=null){
            
            if(oldCard!=null && newCard!=null){//update mode
                if(storedCards.removeIf(card -> card.equals(oldCard))){
                    storedCards.add(newCard);//remove i//remove if any encrypted card matches card given
                }
                storedCards.add(newCard);//add new card to final list
            }else if(oldCard!=null){//delete mode
                storedCards.removeIf(card -> card.equals(oldCard));//remove if any encrypted card matches card given
            }else if(newCard!=null){//append mode
                storedCards.add(newCard);//directly add to final list
            }else{
                //null + null
            }
            
        }
                
        try {//remove old file
            Files.deleteIfExists(Paths.get(currentUser.getUsername()+"/cardVault.dat"));//user's subfolder + filename
        } catch (IOException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        for(byte[] card:storedCards){//for each card append to file
            storeCard(card);
        }
        
    }
    
    private void storeCard(byte[] encryptedCard){//append at the end of file
        
        try {
            //byte[] can be directly appended without objectWriter
            File cardVault = new File(currentUser.getUsername()+"/cardVault.dat");//user's subfolder + filename
            FileOutputStream fos = new FileOutputStream(cardVault, true);
            fos.write(encryptedCard);
        
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
