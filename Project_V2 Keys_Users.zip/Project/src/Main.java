
import Managers.*;
import Utilities.*;

public class Main {
    public static void main(String[] args) {

        KeyHandler.initializeAppKeys();

        User user1 = new User("Dennis","Jo","dionisis","123","j@gmail.com");
        User user2 = new User("Dennis","Jo","dionisis","123","j@gmail.com");
        User user3 = new User("John","JOOOO","giannis","456","j@gmail.com");

        AccountManager.register(user1);
        AccountManager.register(user2);
        AccountManager.register(user3);

        AccountManager.login(user1.getUsername(),"123");
        AccountManager.login(user3.getUsername(),"654");

    }
}
