/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */
package Utilities;

import java.io.Serializable;
import java.util.Objects;


public class CreditCard implements Serializable{
    
    private static final long serialVersionUID = 1L;
    private String cardholder, type, cardNumber;
    private UsefulDate expirationDate;
    private int cvv;
    
    public CreditCard(CreditCard other){
        this.cardholder=other.cardholder;
        this.cardNumber=other.cardNumber;
        this.type=other.type;
        this.expirationDate=other.expirationDate;
        this.cvv=other.cvv;
    }
    
    public CreditCard(String cardholder, String type, String cardNumber, UsefulDate expirationDate, int cvv){
        this.cardholder=cardholder;
        this.cardNumber=cardNumber;
        this.type=type;
        this.expirationDate=expirationDate;
        this.cvv=cvv;
    }
    
    public String toString(){
        return cardNumber;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.cardholder);
        hash = 97 * hash + Objects.hashCode(this.type);
        hash = 97 * hash + Objects.hashCode(this.cardNumber);
        hash = 97 * hash + Objects.hashCode(this.expirationDate);
        hash = 97 * hash + this.cvv;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CreditCard other = (CreditCard) obj;
        if (this.cvv != other.cvv) {
            return false;
        }
        if (!Objects.equals(this.cardholder, other.cardholder)) {
            return false;
        }
        if (!Objects.equals(this.type, other.type)) {
            return false;
        }
        if (!Objects.equals(this.cardNumber, other.cardNumber)) {
            return false;
        }
        if (!Objects.equals(this.expirationDate, other.expirationDate)) {
            return false;
        }
        return true;
    }
    
}
