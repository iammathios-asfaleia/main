
import Encryptions.AsymmetricKeyFactory;
import Encryptions.SymmetricKeyFactory;
import GUI.*;
import Managers.AccountManager;
import Managers.CardManager;
import Managers.KeyHandler;
import Utilities.CreditCard;
import Utilities.UsefulDate;
import Utilities.User;

import javax.crypto.SecretKey;
import java.util.Arrays;


public class Main {
    public static void main(String[] args) {

        KeyHandler.initializeAppKeys();
        User user1 = new User("name","surn","username","1230","ff@mail");
        AccountManager.register(user1);

        CreditCard card1 = new CreditCard("name1","visa","123",new UsefulDate(),123);
        CreditCard card2 = new CreditCard("name2","visa1","456",new UsefulDate(),123);

        //SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(user1.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());
        //
        //byte[] array1 = SymmetricKeyFactory.encrypt(card1,decryptedKey);
        //byte[] array2 = SymmetricKeyFactory.encrypt(card2,decryptedKey);
//
        //if(Arrays.equals(array1,array2)){
        //    System.out.println("equals");
        //}

        CardManager manager1 = new CardManager(user1);
        manager1.updateStorage(null,card1);
        manager1.updateStorage(null,card2);

        manager1.displayCards();
    }
}
