/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */
//package creditcardvault;

package Managers;
import Encryptions.*;
import Utilities.*;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.*;
import javax.crypto.SecretKey;
import javax.swing.*;


public class CardManager {

    private User currentUser;

    public CardManager(User user){
        this.currentUser=user;
    }

    public void displayCards(){

        ArrayList<byte[]> storedCards=readAllCards();//temp card storage(encrypted)

        //read user's secret key from file (encrypted with app's public)
        byte[] encryptedSymmetricKey=KeyHandler.getUserEncryptedSecretKey(currentUser.getUsername());

        //decrypt user's secret key
        SecretKey usersKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(encryptedSymmetricKey, KeyHandler.getAppPrivateKey());

        ArrayList<CreditCard> decryptedCards=new ArrayList<CreditCard>();//temp storage for decrypted cards

        for(byte[] card:storedCards){//for each encrypted card -> decrypt -> add to decrypted storage
            decryptedCards.add((CreditCard)SymmetricKeyFactory.decrypt(card, usersKey));
        }

        System.out.println(decryptedCards);

    }

    private ArrayList<byte[]> readAllCards(){

        ArrayList<byte[]> storedCards=new ArrayList<byte[]>();

        if(Files.exists(Paths.get("Users\\"+currentUser.getUsername()+"\\cardVault.dat"))) {

            try {

                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Users\\" + currentUser.getUsername() + "\\cardVault.dat"));//user's subfolder + filename

                byte[] encryptedCard = (byte[]) ois.readObject();

                if (encryptedCard != null) {//ensure null won't be added to arraylist
                    storedCards.add(encryptedCard);
                }

                while (encryptedCard != null) {//while there is something to read, keep reading
                    try {
                        encryptedCard = (byte[]) ois.readObject();
                        if (encryptedCard != null) {//ensure null won't be added to arraylist
                            storedCards.add(encryptedCard);
                        }
                    } catch (EOFException ex) {
                        System.out.println("eof");
                        break;
                    }
                }

                if(storedCards!=null){
                    System.out.println("All cards read");
                }else{
                    System.out.println("Nothing read");
                }

                ois.close();

                return storedCards;//return results

            } catch (FileNotFoundException exception) {
                exception.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Nothing read");
        return null;
    }

    public boolean updateStorage(CreditCard oldCard, CreditCard newCard){
        //old card + new card = edit mode
        //null + new card = append mode
        //old card + null = delete mode

        boolean exists = false;
        //get user's secret key from file (has been encrypted with app's public)
        SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());

        ArrayList<byte[]> storedCards=readAllCards();

        if(storedCards!=null){
            System.out.println("Found cards");

            if(oldCard!=null){//update or edit mode

                System.out.println("Append/Edit");
                byte[] symmetricallyEncryptedOldCard=SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt old card

                if(storedCards.removeIf(card -> Arrays.equals(card, symmetricallyEncryptedOldCard))){
                    exists=true;
                    if(newCard!=null) {
                        System.out.println("Add edited card");
                        byte[] symmetricallyEncryptedNewCard=SymmetricKeyFactory.encrypt(newCard, decryptedKey);//encrypt new card
                        storedCards.add(symmetricallyEncryptedNewCard);//add new card to final list
                    }

                    try {//remove old file
                        System.out.println("Removing Old File");
                        Files.deleteIfExists(Paths.get("Users\\"+currentUser.getUsername()+"\\cardVault.dat"));//user's subfolder + filename
                    } catch (IOException ex) {
                        Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
                        exists = false;
                    }

                    for(byte[] card:storedCards){//for each card append to file
                        if(!storeCard(card)){
                            exists = false;
                        }
                    }
                }
            }

        }else if(oldCard==null && newCard!=null){//if adding a new card and file does not exist
            System.out.println("Adding new card without pre-existing file");
            byte[] symmetricallyEncryptedNewCard=SymmetricKeyFactory.encrypt(newCard, decryptedKey);//encrypt new card
            storeCard(symmetricallyEncryptedNewCard);//add new card to file
        }
        return exists;
    }

    private boolean storeCard(byte[] encryptedCard){//append at the end of file

        //byte[] can be directly appended without objectWriter
        File cardVault = new File("Users\\"+currentUser.getUsername()+"\\cardVault.dat");//user's subfolder + filename
        ObjectOutputStream output;
        FileOutputStream fos = null;

        try {

            if(cardVault.exists()){
                fos = new FileOutputStream(cardVault, true);
                output = new ObjectOutputStream(fos){
                    public void writeStreamHeader(){

                    }
                };
            }else{
                fos = new FileOutputStream(cardVault);
                output = new ObjectOutputStream(fos);
            }

            output.writeObject(encryptedCard);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (IOException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }finally {
            try{
                if(fos!=null){
                    fos.flush();
                    fos.close();
                }
            }catch (IOException e){
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public boolean cardExists(CreditCard oldCard){

        SecretKey decryptedKey=(SecretKey)AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());
        byte[] encryptedOldCard = SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt old card
        return readAllCards().contains(encryptedOldCard);
    }
}
