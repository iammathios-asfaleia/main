/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;
import Encryptions.*;
import Utilities.*;

import javax.crypto.SecretKey;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;

public class KeyHandler {

    public static void initializeAppKeys(){

        Path privateKeyPath = Paths.get("AppKeys\\privateKey");
        Path publicKeyPath = Paths.get("AppKeys\\publicKey");

        // if at least one of private or public keys does not exist create everything from scratch
        if(Files.notExists(privateKeyPath) || Files.notExists(publicKeyPath)){

            Path path = Paths.get("AppKeys\\");// App keys folder

            if (!Files.exists(path)) {
                try {
                    Files.createDirectories(path); // Create app keys folder
                } catch (IOException e) {
                    //failed to create directory
                    e.printStackTrace();
                }
            }
            writeAppsPairKeysToFile();
        }
    }

    //================WRITE_PAIR_KEYS_TO_FILE==============================
    public static void writeAppsPairKeysToFile(){
        KeyPair keyPair = AsymmetricKeyFactory.getKeyPair();

        ObjectOutputStream objectOut=null;

        try{
            // Write public app key to file
            objectOut = new ObjectOutputStream(new FileOutputStream("AppKeys\\publicKey"));
            objectOut.writeObject(keyPair.getPublic()); System.out.println("publicKey written");


            // Write private app key to file
            objectOut = new ObjectOutputStream(new FileOutputStream("AppKeys\\privateKey"));
            objectOut.writeObject(keyPair.getPrivate()); System.out.println("privateKey written");

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                objectOut.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    //================READ_PUBLIC_AES_KEY==============================
    public static PublicKey getAppPublicKey(){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("AppKeys\\publicKey"));
            PublicKey publicKey = (PublicKey) objectInput.readObject();

            return publicKey;

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

    //================READ_PRIVATE_AES_KEY==============================
    public static PrivateKey getAppPrivateKey(){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("AppKeys\\privateKey"));
            PrivateKey privateKey = (PrivateKey) objectInput.readObject();

            return privateKey;

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

    //================GET_USER_ENCRYPTED_SYMMETRIC_KEY==============================
    public static byte[] getUserEncryptedSecretKey(String username){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("Users\\"+username+"\\PersonalDetails"));
            User user = (User) objectInput.readObject();

            return user.getEncryptedSymmetric();

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

}
