/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Utilities;
import Encryptions.*;
import Managers.KeyHandler;

import javax.crypto.SecretKey;
import java.io.Serializable;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Arrays;

public class User implements Serializable {
    private String name,surname,username,salt,digest,mail;
    private byte[] encryptedSymmetric;

    public User(String name,String surname,String username,String password,String mail){
        this.name=name;
        this.surname=surname;
        this.username=username;
        this.mail=mail;
        this.salt= DigestGenerator.generateRandomSalt();
        this.digest=DigestGenerator.generateDigest(password,this.salt);
        createEncryptSymmetricKey();
    }

    //======================FINALIZE_USER_TO_WRITE_TO_FILE======================//
    private void createEncryptSymmetricKey(){

        SecretKey userSecretKey = SymmetricKeyFactory.createSymmetricalKey(); // Get secret key
        PublicKey publicKey = KeyHandler.getAppPublicKey();// Get App public key

        this.encryptedSymmetric = AsymmetricKeyFactory.encryptWithPublic(userSecretKey,publicKey);

    }

    //============================GETTERS=================================================
    public String getSalt() {return salt;}

    public String getDigest() { return digest; }

    public String getUsername() { return username; }

    public byte[] getEncryptedSymmetric() { return encryptedSymmetric; }


    //============================to_STRING=================================================

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", username='" + username + '\'' +
                ", salt='" + salt + '\'' +
                ", digest='" + digest + '\'' +
                ", mail='" + mail + '\'' +
                ", encryptedSymmetric=" + Arrays.toString(encryptedSymmetric) +
                '}';
    }
}
