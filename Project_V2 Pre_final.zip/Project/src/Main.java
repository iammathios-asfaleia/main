
import Managers.*;
import Utilities.*;

public class Main {
    public static void main(String[] args) {

        KeyHandler.initializeAppKeys();

        User user1 = new User("Dennis","Jo","dionisis","123","j@gmail.com");
        User user2 = new User("Dennis","Jo","dionisis","123","j@gmail.com");
        User user3 = new User("John","JOOOO","giannis","456","j@gmail.com");

        AccountManager.register(user1);
        AccountManager.register(user2);
        AccountManager.register(user3);

        AccountManager.login(user1.getUsername(),"123");
        AccountManager.login(user3.getUsername(),"654");

        CreditCard card1 = new CreditCard("Mathaios","MasterCard","27386983",new UsefulDate(),964);
        CardManager manager1 = new CardManager(user1);

        manager1.addCard("Mathaios","MasterCard","27386983",new UsefulDate(),964);
        manager1.addCard("Mathaios","MasterCard","00000000",new UsefulDate(),964);
        manager1.displayCards();
    }
}
