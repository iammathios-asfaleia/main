
import Managers.KeyHandler;

import GUI.HomePage;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KeyHandler.initializeAppKeys();
        new HomePage();
    }
    
}
