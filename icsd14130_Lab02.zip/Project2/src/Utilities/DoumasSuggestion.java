/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Utilities;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Wrapper class used for ease of storage and
 * retrieval of encrypted cards (as objects)
 * Also contains the type of said card
 * to prevent decryption of card to find
 * all of a specified type
 */
public final class DoumasSuggestion implements Serializable {

    private static final long serialVersionUID = 1L;

    private byte[] getByteArray;
    private String type;

    public DoumasSuggestion(byte[] encryptedCard){
        this.getByteArray =encryptedCard;
    }

    public DoumasSuggestion(byte[] encryptedCard, String type){
        this(encryptedCard);
        this.type=type;
    }

    public byte[] getByteArray() {
        return getByteArray;
    }

    public String getType() {return type;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DoumasSuggestion that = (DoumasSuggestion) o;
        System.out.println("comparing byte[]");
        System.out.println("this hashcode: "+hashCode());
        System.out.println("that hashcode: "+that.hashCode());
        return Arrays.equals(getByteArray, that.getByteArray);
    }

    @Override
    public int hashCode() {
        System.out.println("");
        return Arrays.hashCode(getByteArray);
    }
}
