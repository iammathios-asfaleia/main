/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;

import Encryptions.*;
import Utilities.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.*;
import javax.crypto.SecretKey;
import javax.swing.*;


/**------------CLASS DESCRIPTION------------
    This class is used to provide its methods as 
    services for creating, editing and removing cards
 ------------CLASS DESCRIPTION------------*/

public final class CardManager {

    
    /**
        This method reads wrapped encrypted card objects from file
        decrypts and returns them in their original form
     */
    public static ArrayList<CreditCard> displayCards(String username, String type) {

        ArrayList<DoumasSuggestion> storedCards = readWrappedCards(username);//temp card storage with encrypted cards(byte[]) wrapped to objects

        //read user's secret key from file (encrypted with app's public)
        byte[] encryptedSymmetricKey = KeyHandler.getUserEncryptedSecretKey(username);

        //decrypt user's secret key
        SecretKey usersKey = (SecretKey) AsymmetricKeyFactory.decryptAsymmetric(encryptedSymmetricKey, KeyHandler.getAppPrivateKey());

        ArrayList<CreditCard> decryptedCards = new ArrayList<CreditCard>();//temp storage for decrypted cards

        if (storedCards != null) {
            for (DoumasSuggestion wrappedCard : storedCards) {//for each wrapped card -> get encrypted byte[] -> decrypt -> add to decrypted storage
                if(type.equalsIgnoreCase(wrappedCard.getType())){
                    decryptedCards.add((CreditCard) SymmetricKeyFactory.decrypt(wrappedCard.getByteArray(), usersKey));
                }
            }
        }

        //System.out.println(decryptedCards);

        return decryptedCards;
    }


    
    /**
        This method is used to remove or edit a card
        from file depending on the input.
        First it removes the old card, and if a new
        card is given it appends it to file (edit card
        mechanism)
     */
    public static boolean updateStorage(String username, CreditCard oldCard, CreditCard newCard) {

        boolean exists = false;//flag if old cards is in storage
        
        //get user's secret key from file (has been encrypted with app's public)
        SecretKey decryptedKey = (SecretKey) AsymmetricKeyFactory.decryptAsymmetric(KeyHandler.getUserEncryptedSecretKey(username), KeyHandler.getAppPrivateKey());

        ArrayList<DoumasSuggestion> storedCards=readWrappedCards(username);//read wrapped cards

        if (storedCards != null) {//ensure there are cards

            byte[] symmetricallyEncryptedCard = SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt old card

            //remove any wrapped object that contains the encrypted old card
            if (storedCards.removeIf(storedCard -> Arrays.equals(storedCard.getByteArray(), symmetricallyEncryptedCard))) {
                exists = true;

                if(newCard!=null){//this check will conclude if we are in edit mode
                    byte[] encryptedEditedCard=SymmetricKeyFactory.encrypt(newCard, decryptedKey);
                    storedCards.add(new DoumasSuggestion(encryptedEditedCard, newCard.getType()));
                }

                try {//remove old file
                    //System.out.println("Removing Old File");
                    Files.deleteIfExists(Paths.get("Users\\" + username + "\\cardVault.dat"));//user's subfolder + filename
                } catch (IOException ex) {
                    Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
                    exists = false;
                }

                for (DoumasSuggestion card : storedCards) {//for each wrapped card in arraylist
                    storeCard(username, card);//store to file
                }
            }

        } else {
            //System.out.println("Card not found");
        }
        return exists;
    }


    /**
     * This method reads and returns all encrypted cards
     * wrapped in an assisting object
     */
    public static ArrayList<DoumasSuggestion> readWrappedCards(String username) {

        ArrayList<DoumasSuggestion> storedCards = new ArrayList<DoumasSuggestion>();//wrapped cards in storage
        DoumasSuggestion wrappedCard;

        if (Files.exists(Paths.get("Users\\" + username + "\\cardVault.dat"))) {

            try {

                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Users\\" + username + "\\cardVault.dat"));//user's subfolder + filename

                do {//while there is something to read, keep reading
                    try {
                        wrappedCard = (DoumasSuggestion) ois.readObject();
                        if (wrappedCard != null) {//ensure null won't be added to arraylist

                            storedCards.add(wrappedCard);

                        }
                    } catch (EOFException ex) {
                        break;
                    } catch (StreamCorruptedException sce){
                        JOptionPane.showMessageDialog(null,"Your data has been compromised");
                        break;
                    }
                } while (wrappedCard != null);

                if (storedCards != null) {
                    //System.out.println("All cards read");
                } else {
                    //System.out.println("Nothing read");
                }

                ois.close();

                return storedCards;//return results

            } catch (FileNotFoundException exception) {
                exception.printStackTrace();
            } catch (InvalidClassException ice){
                //System.out.println("Cards have been edited without permission");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        //System.out.println("Nothing read");
        return null;
    }

    /**
     * This method reads all wrapped encrypted cards,
     * unwraps them and return an ArrayList containing
     * encrypted cards
     */
    public static ArrayList<byte[]> readUnwrappedCards(String username){

        ArrayList<DoumasSuggestion> wrappedCards=readWrappedCards(username);//wrapped cards

        ArrayList<byte[]> unwrappedCards=new ArrayList<byte[]>();//encrypted cards
        
        for (DoumasSuggestion ds:wrappedCards){
            unwrappedCards.add(ds.getByteArray());
        }

        return unwrappedCards;
    }

    /**
     * Method to store the encrypted cards wrapped
     * in an assisting object
     */
    public static boolean storeCard(String username, DoumasSuggestion wrappedCard) {//append at the end of file

        File cardVault = new File("Users\\" + username + "\\cardVault.dat");//user's subfolder + filename
        ObjectOutputStream output;
        FileOutputStream fos = null;

        try {
            if (cardVault.exists()) {//if cards have been stored before
                //System.out.println("Appending to file");
                fos = new FileOutputStream(cardVault, true);
                output = new ObjectOutputStream(fos) {
                    public void writeStreamHeader() {//removing stream header. Used only for 1st card
                    }
                };
            } else {
                //System.out.println("Creating new file for cards");
                fos = new FileOutputStream(cardVault);
                output = new ObjectOutputStream(fos);
            }

            output.writeObject(wrappedCard);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (IOException ex) {
            Logger.getLogger(CardManager.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } finally {
            try {
                if (fos != null) {
                    fos.flush();
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    /**
     * This method gets a card, encrypts it and
     * after reading the encrypted cards from file
     * checks if any of them match the card given
     */
    public static boolean cardExists(String username, CreditCard oldCard) {
        boolean exists=false;
        SecretKey decryptedKey = (SecretKey) AsymmetricKeyFactory.decryptAsymmetric(KeyHandler.getUserEncryptedSecretKey(username), KeyHandler.getAppPrivateKey());
        byte[] encryptedOldCard = SymmetricKeyFactory.encrypt(oldCard, decryptedKey);//encrypt old card

        for(byte[] b: readUnwrappedCards(username)){
            if(Arrays.equals(b,encryptedOldCard)){
                exists=true;
                //System.out.println("Found card");
                break;
            }
        }

        if (exists) {
            //System.out.println("Card Exists");
        } else {
            //System.out.println("Card does not exist");
        }

        return exists;
    }

}
