/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;

import Encryptions.*;
import Utilities.DoumasSuggestion;

import javax.crypto.SecretKey;
import java.io.*;
import java.nio.file.*;
import java.security.PrivateKey;
import java.util.*;


/**
 * This class serves as a collection of services to
 * ensure the integrity of the user's cards
 */
public final class IntegrityManager {


    /**
     * This method is used to produce the digest that occurs
     * after hashing the user's cards and then hashing this
     * digest with the username
     */
    private static byte[] integrityDigest(String username){

        String stringDigest="error";//digest of user's cards in string format

        ArrayList<byte[]> storedCards=CardManager.readUnwrappedCards(username);//encrypted cards

        byte[] finalDigest=null;//result of hashing username and stringDigest

        File cardVault=new File("Users\\"+username+"\\cardVault.dat");

        if(cardVault.exists()){//if user has cards
            stringDigest=DigestGenerator.integrityDigestOne(storedCards);

            if(!stringDigest.equals("error")){
                finalDigest=DigestGenerator.getSHA3_256(username, stringDigest);
            }
        }

        System.out.println(DigestGenerator.toHexString(finalDigest));

        return finalDigest;
    }


    /**
     * This method is used to store in file
     * the digest that was created from the cards
     * and username signed by the user and encrypted
     * with the app's public key
     */
    public static byte[] getSignature(String username, boolean login){

        Path cardsLocation=Paths.get("Users\\"+username+"\\cardVault.dat");
        byte[] encryptedSignature=null;//signed and encrypted digest

        if(Files.exists(cardsLocation)) {

            byte[] digest = integrityDigest(username);//digest from cards and username

            PrivateKey appPrivate = KeyHandler.getAppPrivateKey();

            byte[] digitalSign = AsymmetricKeyFactory.encryptAsymmetrically(digest, appPrivate);//encrypted digest (not signed yet)

            //read user's secret key from file (encrypted with app's public)
            byte[] encryptedSymmetricKey = KeyHandler.getUserEncryptedSecretKey(username);

            //decrypt user's secret key
            SecretKey usersKey = (SecretKey) AsymmetricKeyFactory.decryptAsymmetric(encryptedSymmetricKey, KeyHandler.getAppPrivateKey());

            encryptedSignature = SymmetricKeyFactory.encrypt(digitalSign, usersKey);

            if (!login) {
                storeToFile(username, encryptedSignature);
            }
        }

        return encryptedSignature;
    }


    /**
     * Method used to store the signature
     * used for integrity checking
     */
    private static void storeToFile(String username, byte[] signature){
        File signatureFile = new File("Users\\" + username + "\\Signature.dat");//user's subfolder + filename
        ObjectOutputStream output;
        DoumasSuggestion objectSignature=new DoumasSuggestion(signature);
        try{
            output=new ObjectOutputStream(new FileOutputStream(signatureFile));

            output.writeObject(objectSignature);
            output.flush();
            output.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    /**
     * Method used to compare signatures
     */
    public static boolean isEqual(String username, byte[] newSignature){

        Path signatureLocation= Paths.get("Users\\" + username + "\\Signature.dat");
        File signatureFile = new File("Users\\" + username + "\\Signature.dat");//user's subfolder + filename

        ObjectInputStream ois;

        try{
            ois=new ObjectInputStream(new FileInputStream(signatureFile));

            if(Files.exists(signatureLocation)){
                DoumasSuggestion storedSignature=(DoumasSuggestion)ois.readObject();

                byte[] byteSignature=storedSignature.getByteArray();

                if(Arrays.equals(newSignature, byteSignature)){
                    System.out.println("Storing Signature to File");
                    return true;
                }
            }

            ois.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    }
}
