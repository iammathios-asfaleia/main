/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;
import Encryptions.*;
import Utilities.*;

import java.io.*;
import java.nio.file.*;
import java.security.*;

/**
 * This class is using methods to provide
 * services to other classes for initializeAppKeys
 * and it manages key requests from the program
 */
public final class KeyHandler {

    /**
     * This method initializes the App's keys one time
     * If either file containing a key is missing, the method creates again those files
     */
    public static void initializeAppKeys(){

        Path privateKeyPath = Paths.get("AppKeys\\privateKey");
        Path publicKeyPath = Paths.get("AppKeys\\publicKey");

        // if at least one of private or public keys does not exist create everything from scratch
        if(Files.notExists(privateKeyPath) || Files.notExists(publicKeyPath)){

            Path path = Paths.get("AppKeys\\");// App keys folder

            if (!Files.exists(path)) {
                try {
                    Files.createDirectories(path); // Create app keys folder
                } catch (IOException e) {
                    //failed to create directory
                    e.printStackTrace();
                }
            }
            writeAppsPairKeysToFile();
        }
    }

    /**
     * This method writes the App's private and public keys to files
     */
    public static void writeAppsPairKeysToFile(){
        KeyPair keyPair = AsymmetricKeyFactory.getKeyPair();

        ObjectOutputStream objectOut=null;

        try{
            // Write public app key to file
            objectOut = new ObjectOutputStream(new FileOutputStream("AppKeys\\publicKey"));
            objectOut.writeObject(keyPair.getPublic()); System.out.println("publicKey written");


            // Write private app key to file
            objectOut = new ObjectOutputStream(new FileOutputStream("AppKeys\\privateKey"));
            objectOut.writeObject(keyPair.getPrivate()); System.out.println("privateKey written");

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try{
                objectOut.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }


    /**
     * This method returns public key
     */
    public static PublicKey getAppPublicKey(){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("AppKeys\\publicKey"));
            PublicKey publicKey = (PublicKey) objectInput.readObject(); // Read from file the public key

            return publicKey;

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }


    /**
     * This method returns private key
     */
    public static PrivateKey getAppPrivateKey(){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("AppKeys\\privateKey"));
            PrivateKey privateKey = (PrivateKey) objectInput.readObject(); // Read private key from file

            return privateKey;

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }


    /**
     * This method is used to return the user's encrypted secret key
     */
    public static byte[] getUserEncryptedSecretKey(String username){

        ObjectInputStream objectInput=null;

        try {
            objectInput = new ObjectInputStream(new FileInputStream("Users\\"+username+"\\PersonalDetails"));
            User user = (User) objectInput.readObject(); // Read the user details from file

            return user.getEncryptedSymmetric(); // return the user encrypted secret key

        } catch (FileNotFoundException exception) {
            exception.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            try{
                objectInput.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

}
