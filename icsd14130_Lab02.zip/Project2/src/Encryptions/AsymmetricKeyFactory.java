/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Encryptions;

import java.io.*;
import java.security.*;
import java.util.logging.*;
import javax.crypto.*;



    /*------------CLASS DESCRIPTION------------
    Class consists of only static methods that
    operate as services to other classes in project,
    so that the same code can be reused without
    creating unnecessary objects in memory
    Services provided are Key generation and
    encryption/decryption with private/public Keys
     ------------CLASS DESCRIPTION------------*/

public final class AsymmetricKeyFactory {



    /*
    Here the algorithm is specified along with the bit size
    In general it would be better to give them as parameters,
    e.g. getKeyPair(String algorithm, int bitSize)
    but for this project it won't be necessary since it would
    require input checks even though only 2048 bit RSA is required
     */
    public static KeyPair getKeyPair(){

        //https://docs.oracle.com/javase/8/docs/api/java/security/Key.html
        //https://docs.oracle.com/javase/8/docs/api/java/security/KeyPairGenerator.html
        
        try {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");//Specify encrypting algorithm (RSA)
            generator.initialize(2048, new SecureRandom());//2048=bit size
            //SecureRandom is chosen to comply with FIPS 140-2, Security Requirements for Cryptographic Modules
            //https://csrc.nist.gov/publications/detail/fips/140/2/final
            
            KeyPair keyPair = generator.generateKeyPair();//KeyPair object contains both private and public keys
            
            return keyPair;
            
        } catch (NoSuchAlgorithmException ex) {
            System.out.println(ex.getLocalizedMessage());
        }
        return null;
    }
    






    //-----------------------------------------------------ENCRYPTION-----------------------------------------------------


    /*
        This method is used for encrypting byte[]
        byte[] is chosen to make process more generic and
        not bound by a specific object class (e.g. CreditCard)
        Key is super class of PrivateKey and PublicKey
        (or any key used for cryptography)
        so by with same method encryption with either
        private or public key can be used
     */

    public static byte[] encryptAsymmetrically(Object plainText, Key key){
        
        try {
            //encryption set up
            Cipher encryptCipher = Cipher.getInstance("RSA");//cipher is the encryption/decryption mechanism. in this case for rsa
            encryptCipher.init(Cipher.ENCRYPT_MODE, key);//parameters to define process specs
            
            byte[] serializedPlain=serialize(plainText);//object->serialization->byte[]
            
            byte[] cipherText = encryptCipher.doFinal(serializedPlain);//byte[]->encryption->encrypted byte[]
            
            return cipherText;
            
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
        
    }

    
    //-----------------------------------------------------ENCRYPTION-----------------------------------------------------
    
    




    
    //-----------------------------------------------------DECRYPTION-----------------------------------------------------


    /*
        This method is used for decrypting byte[]
        parameters are chosen with same logic as above
        Object is returned to ensure method is generic
        Each class that utilizes this method casts
        Object to expected object type
     */

    public static Object decryptAsymmetric(byte[] cipherText, Key key){
        try {
            
            //decryption set up
            Cipher decryptionCipher = Cipher.getInstance("RSA");//cipher is the encryption/decryption mechanism. in this case for rsa
            decryptionCipher.init(Cipher.DECRYPT_MODE, key);//parameters to define process specs
            
            byte[] serializedObject=decryptionCipher.doFinal(cipherText);//encrypted byte[]->decryption->byte[]
            Object plainText=deserialize(serializedObject);//byte[]->object
            return plainText;
            
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return "failed asymmetric decryption";
    }
    
    //-----------------------------------------------------DECRYPTION-----------------------------------------------------
    
    







    //-----------------------------------------------------SERIALIZATION-----------------------------------------------------



    /*
        Supporting methods used for converting Object
        to byte[] and vice versa
        https://stackoverflow.com/questions/3736058/java-object-to-byte-and-byte-to-object-converter-for-tokyo-cabinet/3736091
     */


    public static byte[] serialize(Object obj){
        try {
            ByteArrayOutputStream container = new ByteArrayOutputStream();//empty container that will keep the bytes from conversion
            ObjectOutputStream os = new ObjectOutputStream(container);//instead of file use the container
            os.writeObject(obj);//write to container
            return container.toByteArray();//return byte[]
        } catch (IOException ex) {
            Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public static Object deserialize(byte[] data){
        ObjectInputStream is = null;
        try {
            ByteArrayInputStream container = new ByteArrayInputStream(data);//container that has the byte[] from a serialized object
            is = new ObjectInputStream(container);//instead of file use the container
            return is.readObject();//return Object, casting is needed according to object that is expected
        } catch (IOException ex) {
            Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                is.close();
            } catch (IOException ex) {
                Logger.getLogger(AsymmetricKeyFactory.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return null;
    }
    
    //-----------------------------------------------------SERIALIZATION-----------------------------------------------------
}
