/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Encryptions;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Random;

/**
 * This class serves as a provider of services for
 * generating and comparing a digest
 */
public final class DigestGenerator {    // credits https://www.geeksforgeeks.org/sha-256-hash-in-java/


    /**
     * Hash the password & salt with SHA3-256 into an array of bytes
     */
    public static byte[] getSHA3_256(String str1, String str2) {

        MessageDigest md;
        String input = str1 + str2; // string to hash

        try {
            md = MessageDigest.getInstance("SHA3-256"); // Static getInstance method is called to specify hashing

            return md.digest(input.getBytes(StandardCharsets.UTF_8));// digest() method called to calculate message digest of an input and return array of bytes

        } catch (NoSuchAlgorithmException e) {
            System.out.println("! NoSuchAlgorithmException !\n");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Hash (SHA3-256) the ArrayList with the encrypted cards
     * Returns a String (digest)
     */
    public static String integrityDigestOne(ArrayList<byte[]> storedCards) {

        MessageDigest md;
        byte[] cardDigest = AsymmetricKeyFactory.serialize(storedCards);
        String input = toHexString(cardDigest); // make a String out of the byte[] cardDigest

        try {
            md = MessageDigest.getInstance("SHA3-256"); // Static getInstance method is called to specify hashing

            return input;// digest() method called to calculate message digest of an input and return array of bytes

        } catch (NoSuchAlgorithmException e) {
            System.out.println("! NoSuchAlgorithmException !\n");
            e.printStackTrace();
        }
        return "error";
    }

    /**
     * Generate a random salt (10 letters)
     */
    public static String generateRandomSalt() {

        byte[] array = new byte[10];
        new Random().nextBytes(array);

        return new String(array, Charset.forName("UTF-8"));
    }

    /**
     * Converts a hexadecimal byte[] array into a String
     * Returns the digest
     */
    public static String toHexString(byte[] hash) {

        BigInteger number = new BigInteger(1, hash); // Convert byte array into signum representation
        StringBuilder hexString = new StringBuilder(number.toString(16)); // Convert message digest into hex value

        while (hexString.length() < 32){ // Pad with leading zeros
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

    /**
     * Checks if two digests are equal
     */
    public static boolean digestEquality(String digest1, String digest2) {
        return (digest1.equals(digest2) ? true : false);
    }

    /**
     * Returns a String(a digest) that gets generated when hashing(SHA3-256) a password with a salt
     */
    public static String generateDigest(String password, String salt) {
        return DigestGenerator.toHexString(DigestGenerator.getSHA3_256(password, salt));
    }

}
