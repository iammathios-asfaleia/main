/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Encryptions;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.security.*;

/**
 * Class consists of only static methods that
 * operate as services to other classes in project,
 * so that the same code can be reused without
 * creating unnecessary objects in memory
 * Services provided is Key generation and
 * encryption/decryption with secret key
 */

public final class SymmetricKeyFactory {

    /**
     * This method generate and returns the secret key using the algorithm (AES)
     * @return secret_key
     */
    public static SecretKey createSymmetricalKey() {

        KeyGenerator keyGenerator;

        try {

            keyGenerator = KeyGenerator.getInstance("AES"); // Encrypt algorithm (AES)
            keyGenerator.init(256); // byte key generator 256
            SecretKey secretKey = keyGenerator.generateKey(); // Secret Key object contains the key
            byte[] aeskey = secretKey.getEncoded(); // Returns the key in its primary encoding format, or null if the key does not support encoding

            SecretKey secret_key = new SecretKeySpec(aeskey, "AES"); //It can be used to construct a SecretKey from a byte array using (AES)
            return secret_key; // Return the secret key

        }catch (NoSuchAlgorithmException ex){
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * This methods is used to encrypt the
     * object (witch contains cards information) with secret key
     * @param obj
     * @param secret_key
     */
    public static byte[] encrypt(Object obj,SecretKey secret_key) {

        byte[] value=AsymmetricKeyFactory.serialize(obj); // Make the object serializable

        try{
            Cipher aescipher = Cipher.getInstance("AES"); // Use the Cipher algorithm (AES)
            aescipher.init(Cipher.ENCRYPT_MODE,secret_key); // we use the secret key encrypt mode

            return aescipher.doFinal(value); // Here we doFinal encrypt the value with the secret key and return it

        }catch (InvalidKeyException|BadPaddingException|IllegalBlockSizeException|NoSuchPaddingException|NoSuchAlgorithmException exception){
            exception.printStackTrace();
        }
        return null;
    }

    /**
     * This method is used to decrypt the encrypted value with the secret key
     * @param encryption_value
     * @param secret_key
     * @return
     */
    public static Object decrypt(byte[] encryption_value,SecretKey secret_key) {

        try{
            Cipher aescipher = Cipher.getInstance("AES");// Use the Cipher algorithm (AES)
            aescipher.init(Cipher.DECRYPT_MODE,secret_key);// we use the secret key decrypt mode

            byte[] value=aescipher.doFinal(encryption_value); // Here we doFinal decrypt the encrypted value with the secret key

            Object original=AsymmetricKeyFactory.deserialize(value); // We deserialize the object and bring it to the original form

            return original; // Return the object

        }catch (InvalidKeyException|BadPaddingException|IllegalBlockSizeException|NoSuchPaddingException|NoSuchAlgorithmException exception){
            exception.printStackTrace();
        }
        return null;
    }

}
