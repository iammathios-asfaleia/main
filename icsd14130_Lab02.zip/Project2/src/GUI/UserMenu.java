/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.*;
import Utilities.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * This class is the graphical representation of the
 * services provided to the user for managing their cards
 */
public final class UserMenu extends JFrame{

    private String username;

    public UserMenu(String username) {
        super("Secure Credit Card Storage - Home");

        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        Container pane = getContentPane();
        //-------------------------------initial window setup-------------------








        //--------------------initializing attributes---------------------------
        JButton displayButton, addButton, logoutButton, updateButton, deleteButton;
        JLabel welcome=new JLabel("What would you like to do today " + username + "?", JLabel.CENTER);
        displayButton=new JButton("Display All Cards");
        addButton=new JButton("Add Card");
        updateButton=new JButton("Edit Card");
        deleteButton=new JButton("Delete Card");
        logoutButton=new JButton("Logout");
        JPanel buttonPanel=new JPanel();
        this.username=username;
        //--------------------initializing attributes---------------------------










        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        welcome.setFont(new Font("ArialBlack", Font.BOLD, 24));
        welcome.setAlignmentX(CENTER_ALIGNMENT);
        welcome.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        buttonPanel.setBackground(Color.decode("#99d9ea"));
        addButton.setFont(new Font("ArialBlack", 0, 16));
        displayButton.setFont(new Font("ArialBlack", 0, 16));
        updateButton.setFont(new Font("ArialBlack", 0, 16));
        deleteButton.setFont(new Font("ArialBlack", 0, 16));
        logoutButton.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------





        //----------------------functionality-----------------------------------
        displayButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){new DisplayCards(username);}});

        addButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ new CardWindow(1, username);}});

        updateButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
            new CardWindow(2, username);
            JOptionPane.showMessageDialog(null, "Insert the credentials of the card you want to edit.");
        }});

        deleteButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
            new CardWindow(3, username);
            JOptionPane.showMessageDialog(null, "Insert the card credentials you want to delete.");
        }});

        logoutButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ logoutActions(); }});
        //----------------------functionality-----------------------------------




        //-------------------------add components-------------------------------
        buttonPanel.add(displayButton);
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(logoutButton);

        pane.add(Box.createVerticalGlue());//filler to separate from top of window
        pane.add(welcome);
        pane.add(buttonPanel);
        pane.add(Box.createVerticalGlue());//filler to separate from bottom of window
        //-------------------------add components-------------------------------


        setVisible(true);
    }


    /**
     * Method used to update the file containing
     * the signature of the encrypted cards
     */
    private void logoutActions(){

        User tempUser=null;

        try{
            ObjectInputStream ois=new ObjectInputStream(new FileInputStream("Users\\"+username+"\\PersonalDetails"));
            tempUser=(User)ois.readObject();
            ois.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if(tempUser!=null && tempUser.isFirstTimeLogin()){AccountManager.updateFirstTimeLogin(tempUser);}

        IntegrityManager.getSignature(username, false);

        dispose();
        new HomePage();

    }


}
