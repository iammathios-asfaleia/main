/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.CardManager;
import Utilities.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * This class is using GUI to display the cards
 * witch the user wants to. (Visa or MasterCard)
 */

public final class DisplayCards extends JFrame {

    private Container pane;
    private JButton type1,type2,back;
    private JLabel label;
    private JPanel buttonPanel,jp;
    private String typeChosen;
    private String username;

    public DisplayCards(String username){
        super("Your Cards");
        jp = new JPanel();
        this.username=username;

        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        pane = getContentPane();
        type1 = new JButton("Visa");
        type2 = new JButton("MasterCard");
        back = new JButton("Back");
        label = new JLabel("Select card type");
        buttonPanel = new JPanel();

        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        label.setFont(new Font("ArialBlack", Font.BOLD, 24));
        label.setAlignmentX(CENTER_ALIGNMENT);
        label.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        pane.setBackground(Color.decode("#99d9ea"));
        buttonPanel.setBackground(Color.decode("#99d9ea"));
        type1.setFont(new Font("ArialBlack", 0, 16));
        type2.setFont(new Font("ArialBlack", 0, 16));
        back.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------

        //--------------------------ACTION_LISTENERS--------------------------
        type1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { typeChosen="Visa"; cardTextArea(); validate();}});
        type2.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { typeChosen="MasterCard"; cardTextArea(); validate();}});
        back.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { dispose(); }});

        pane.add(label);
        buttonPanel.add(type1);
        buttonPanel.add(type2);
        buttonPanel.add(back);
        pane.add(buttonPanel);

        this.setVisible(true);
    }


    /**
     * This method is used to display the cards into a textArea
     */
    private void cardTextArea(){
        // We put to the cardsList array the cards that user chose to display and is comes from the displayCards method
        ArrayList <CreditCard> cardsList = CardManager.displayCards(username, typeChosen);
        jp.removeAll();

        if(cardsList != null) { // If the array list is not null
            System.out.println(cardsList);

            jp.setBackground(Color.decode("#99d9ea"));
            JTextArea txtArea = new JTextArea();

            for (CreditCard card : cardsList) {
                txtArea.append(card.toString()+"\n");
            }
            jp.add(txtArea);
            this.pane.add(jp);
        }else JOptionPane.showMessageDialog(null,"You have no cards.");
    }

}
