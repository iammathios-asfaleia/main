/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.AccountManager;
import Utilities.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class RegisterPage extends JFrame{

    // name,surname,username,mail;
    //salt,digest
    private JTextField nameText, surnameText, passwordText, usernameText, emailText;
    private JLabel message;

    public RegisterPage() {
        super("Secure Credit Card Storage - Authentication");


        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        Container pane = getContentPane();
        //-------------------------------initial window setup-------------------






        //--------------------initializing attributes---------------------------
        JPanel buttonPanel = new JPanel();
        JButton newButton, backButton;
        newButton = new JButton("New User", new ImageIcon("newuser.png"));
        backButton = new JButton("Back");
        this.message = new JLabel("Insert your credentials", JLabel.CENTER);

            //JLabels
        JLabel nameLabel = new JLabel("First Name:");
        JLabel surnameLabel = new JLabel("Last Name:");
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel emailLabel = new JLabel("Email:");

            //JPanels
        JPanel nameTextPanel = new JPanel();//used to avoid textfield expanding more than necessary
        JPanel surnameTextPanel = new JPanel();
        JPanel usernameTextPanel = new JPanel();
        JPanel passwordTextPanel = new JPanel();//same
        JPanel emailTextPanel = new JPanel();

            //JTextFields
        this.nameText = new JTextField(20);
        this.surnameText = new JTextField(20);
        this.usernameText = new JTextField(20);
        this.passwordText = new JPasswordField(20);
        this.emailText = new JTextField(20);
        //--------------------initializing attributes---------------------------








        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane, BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        message.setFont(new Font("ArialBlack", Font.BOLD, 24));
        nameLabel.setFont(new Font("ArialBlack", 0, 16));
        surnameLabel.setFont(new Font("ArialBlack", 0, 16));
        usernameLabel.setFont(new Font("ArialBlack", 0, 16));
        passwordLabel.setFont(new Font("ArialBlack", 0, 16));
        emailLabel.setFont(new Font("ArialBlack", 0, 16));
        message.setAlignmentX(CENTER_ALIGNMENT);
        message.setBounds(0, 0, pane.getWidth() / 4, pane.getWidth() / 4);//set message position dynamic to its container


        nameTextPanel.setBackground(Color.decode("#99d9ea"));
        surnameTextPanel.setBackground(Color.decode("#99d9ea"));
        usernameTextPanel.setBackground(Color.decode("#99d9ea"));
        passwordTextPanel.setBackground(Color.decode("#99d9ea"));
        emailTextPanel.setBackground(Color.decode("#99d9ea"));
        buttonPanel.setBackground(Color.decode("#99d9ea"));
        newButton.setFont(new Font("ArialBlack", 0, 16));
        backButton.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------










        //----------------------functionality-----------------------------------
        newButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if(allFilled()){
                    User currentUser=new User(nameText.getText(), surnameText.getText(), usernameText.getText(), passwordText.getText(), emailText.getText());
                    if(AccountManager.register(currentUser)){
                        JOptionPane.showMessageDialog(null, "Registration Successful.");
                        dispose();
                        new LoginPage();
                    }else{
                        JOptionPane.showMessageDialog(null, "User already exist!!","Failed",JOptionPane.ERROR_MESSAGE);
                    }
                }else{
                    message.setText("Please fill all fields before continuing");
                    message.setForeground(Color.RED);
                }

            }
        });

        backButton.addActionListener(new ActionListener() {public void actionPerformed(ActionEvent e) {dispose(); new HomePage();}});

        //hide error message if user tries to type again
        usernameText.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                message.setForeground(Color.BLACK);
                message.setText("Insert your credentials");
            }
        });
        passwordText.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                message.setForeground(Color.BLACK);
                message.setText("Insert your credentials");
            }
        });
        //----------------------functionality-----------------------------------








        //-------------------------add components-------------------------------
        buttonPanel.add(newButton);
        buttonPanel.add(backButton);

        nameTextPanel.add(nameText);
        surnameTextPanel.add(surnameText);
        usernameTextPanel.add(usernameText);
        passwordTextPanel.add(passwordText);
        emailTextPanel.add(emailText);

        pane.add(Box.createVerticalGlue());//filler to separate from top of window
        pane.add(message);
        pane.add(Box.createGlue());//small empty space between previous and next component
        pane.add(nameLabel);
        pane.add(nameTextPanel);
        pane.add(surnameLabel);
        pane.add(surnameTextPanel);
        pane.add(usernameLabel);
        pane.add(usernameTextPanel);
        pane.add(passwordLabel);
        pane.add(passwordTextPanel);
        pane.add(emailLabel);
        pane.add(emailTextPanel);
        pane.add(buttonPanel);
        pane.add(Box.createVerticalGlue());//filler to separate from bottom of window
        //-------------------------add components-------------------------------


        setVisible(true);


    }

    private boolean allFilled(){

        if(nameText.getText().equals("") || surnameText.getText().equals("") || usernameText.getText().equals("") || passwordText.getText().equals("") || emailText.getText().equals("")){
            return false;
        }

        return true;
    }

}

