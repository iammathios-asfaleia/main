/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Encryptions;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public final class SymmetricKeyFactory {

    // Create symmetric Key
    public static SecretKey createSymmetricalKey() {

        KeyGenerator keyGenerator;

        try {

            keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            SecretKey secretKey = keyGenerator.generateKey();
            byte[] aeskey = secretKey.getEncoded();

            SecretKey secret_key = new SecretKeySpec(aeskey, "AES");
            return secret_key;

        }catch (NoSuchAlgorithmException ex){
            ex.printStackTrace();
        }
        return null;
    }

    // encrypt symmetric key
    public static byte[] encrypt(Object obj,SecretKey secret_key) {
        
        byte[] value=AsymmetricKeyFactory.serialize(obj);
        
        try{
            Cipher aescipher = Cipher.getInstance("AES");
            aescipher.init(Cipher.ENCRYPT_MODE,secret_key);

            return aescipher.doFinal(value);

        }catch (InvalidKeyException|BadPaddingException|IllegalBlockSizeException|NoSuchPaddingException|NoSuchAlgorithmException exception){
            exception.printStackTrace();
        }
        return null;
    }

    // decrypt symmetric key
    public static Object decrypt(byte[] encryption_value,SecretKey secret_key) {

        try{
            Cipher aescipher = Cipher.getInstance("AES");
            aescipher.init(Cipher.DECRYPT_MODE,secret_key);
            
            byte[] value=aescipher.doFinal(encryption_value);
            
            Object original=AsymmetricKeyFactory.deserialize(value);

            return original;

        }catch (InvalidKeyException|BadPaddingException|IllegalBlockSizeException|NoSuchPaddingException|NoSuchAlgorithmException exception){
            exception.printStackTrace();
        }
        return null;
    }

}
