/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

import GUI.*;
import Managers.KeyHandler;


public class Main {
    public static void main(String[] args) {

       KeyHandler.initializeAppKeys();

       new HomePage();

    }
}
