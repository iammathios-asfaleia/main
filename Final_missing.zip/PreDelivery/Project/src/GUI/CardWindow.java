/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Encryptions.AsymmetricKeyFactory;
import Encryptions.SymmetricKeyFactory;
import Managers.*;
import Utilities.*;

import javax.crypto.SecretKey;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public final class CardWindow extends JFrame {

    private JButton confirmAdd, confirmRemove, confirmEdit, back,typeLogo;
    private JTextField cardholder, cardnumber, date, cvv;
    private CreditCard oldCard = null, newCard = null;
    private CardManager myManager;
    private User currentUser;
    private JComboBox type;
    private String cardTypes[]={"Visa","MasterCard"};
    //private Image img;

    public CardWindow(int mode, User currentUser, CardManager myManager) {
        //==========FRAME================================
        super("Card");
        this.currentUser = currentUser;
        this.myManager = myManager;
        //try{
        //    this.img = ImageIO.read(new File("visa.jpeg"));
        //} catch (IOException e) {
        //    e.printStackTrace();
        //}

        setSize(475, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        //===============BUTTONS==========================
        confirmAdd = new JButton("Confirm");
        confirmEdit = new JButton("Edit");
        confirmRemove = new JButton("Remove");
        back = new JButton("Back");
        type = new JComboBox(cardTypes);
        confirmAdd.setBounds(130, 515, 90, 30);
        confirmEdit.setBounds(130, 515, 90, 30);
        confirmRemove.setBounds(130, 515, 90, 30);
        back.setBounds(230, 515, 90, 30);
        type.setBounds(334, 175, 92, 18);

        //typeLogo = new JButton((Action) img);
        //typeLogo.setBounds(334, 194, 92, 48);
        //typeLogo.setBorderPainted(false);

        //===============ADD_ACTION_LISTENERS_TO_BUTTONS===================
        confirmAdd.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { addCardActionListener(); }});
        confirmEdit.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { editCardActionListener(); }});
        confirmRemove.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { deleteCardActionListener(); }});
        back.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { dispose(); }});
        //typeLogo.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) {
        //    try{
        //        if(type.getSelectedIndex()==0){
        //            img = ImageIO.read(new File("visa.jpeg"));;
        //        }else{
        //            img = ImageIO.read(new File("master.jpeg"));;
        //        }
        //    } catch (IOException ex) {
        //        ex.printStackTrace();
        //    }

        //    validate();
        //}});

        //------------------------CARD_NUMBER_FILED----------------------
        cardnumber = new JTextField("");
        final String PL_card = "Insert your card number";
        cardnumber.setText(PL_card);

        cardnumber.addFocusListener(new FocusListener() {
            private boolean showingPlaceholder1 = true;

            @Override
            public void focusGained(FocusEvent e) {
                if (showingPlaceholder1) {
                    showingPlaceholder1 = false;
                    cardnumber.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (cardnumber.getText().isEmpty()) {
                    cardnumber.setText(PL_card);
                    showingPlaceholder1 = true;
                }
            }
        });
        cardnumber.setBounds(50, 137, 349, 33);
        cardnumber.setFont(new Font("Arial", Font.PLAIN, 19));
        cardnumber.setHorizontalAlignment(JTextField.CENTER);


        //------------------------DATE_TEXT_FIELD----------------------
        date = new JTextField();
        final String PL_date = "Date";
        date.setText(PL_date);

        date.addFocusListener(new FocusListener() {
            private boolean showingPlaceholder2 = true;

            @Override
            public void focusGained(FocusEvent e) {
                if (showingPlaceholder2) {
                    showingPlaceholder2 = false;
                    date.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (date.getText().isEmpty()) {
                    date.setText(PL_date);
                    showingPlaceholder2 = true;
                }
            }
        });
        date.setBounds(135, 188, 100, 22);
        date.setFont(new Font("Arial", Font.BOLD, 14));
        date.setHorizontalAlignment(JTextField.CENTER);


        //--------------------USER_NAME_CARD--------------------------
        DocumentFilter filter = new UpperCaseFilter();
        cardholder = new JTextField();
        final String PL_username = "Insert your full name";
        cardholder.setText(PL_username);

        cardholder.addFocusListener(new FocusListener() {
            private boolean showingPlaceholder3 = true;

            @Override
            public void focusGained(FocusEvent e) {
                if (showingPlaceholder3) {
                    showingPlaceholder3 = false;
                    cardholder.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (cardholder.getText().isEmpty()) {
                    cardholder.setText(PL_username);
                    showingPlaceholder3 = true;
                }
            }
        });
        cardholder.setBounds(47, 210, 280, 22);
        cardholder.setFont(new Font("Arial", Font.PLAIN, 14));
        cardholder.setHorizontalAlignment(JTextField.CENTER);
        ((AbstractDocument) cardholder.getDocument()).setDocumentFilter(filter); // Make key words Upper Case


        //----------------------CVV_CARD---------------------------
        cvv = new JTextField();
        cvv.setBounds(283, 346, 32, 27);
        cvv.setFont(new Font("Arial", Font.PLAIN, 14));
        cvv.setHorizontalAlignment(JTextField.CENTER);

        Container pane = new Icon();

        pane.setBackground(Color.decode("#99d9ea"));


        //==========Set_buttons_into_pane=================
        if (mode == 1) {
            pane.add(confirmAdd);
        } else if (mode == 2) {
            pane.add(confirmEdit);
        } else {
            pane.add(confirmRemove);
        }

        pane.add(back);


        //==========Set_text_fields_into_pane=============
        pane.add(cardnumber);
        pane.add(cardholder);
        pane.add(date);
        pane.add(cvv);
        pane.add(type);
        //pane.add(typeLogo);

        setContentPane(pane);
        pane.setLayout(null);
        pane.revalidate();
        setVisible(true);
    }

    private void addCardActionListener() {

        newCard = readCardInfo();//card that will be stored (not encrypted)

        //user's key
        SecretKey decryptedKey = (SecretKey) AsymmetricKeyFactory.decryptWithPrivate(currentUser.getEncryptedSymmetric(), KeyHandler.getAppPrivateKey());

        byte[] symmetricallyEncryptedNewCard = SymmetricKeyFactory.encrypt(newCard, decryptedKey);//encrypted card

        DoumasSuggestion wrappedCard = new DoumasSuggestion(symmetricallyEncryptedNewCard, newCard.getType());//wrapper object to store in file

        myManager.storeCard(wrappedCard);//write to file

        JOptionPane.showMessageDialog(null, "Card successfully added!");
        dispose();

    }

    private void editCardActionListener() {

        if (oldCard == null && newCard == null) {//if user
            oldCard = readCardInfo();
            if (myManager.cardExists(oldCard)) {
                JOptionPane.showMessageDialog(null, "Insert new card credentials.");
            } else {
                JOptionPane.showMessageDialog(null, "Card does not exist!");
            }
            cardholder.setText("");
            cardnumber.setText("");
            date.setText("");
            cvv.setText("");

        } else if (myManager.cardExists(oldCard)) {
            newCard = readCardInfo();
            if (myManager.updateStorage(oldCard, newCard)) {
                JOptionPane.showMessageDialog(null, "Card successfully edited.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Card could not be edited!");
            }
        }

    }

    private void deleteCardActionListener() {

        if (oldCard == null) {

            oldCard = readCardInfo();
            if (myManager.cardExists(oldCard)) {
                int option = JOptionPane.showConfirmDialog(null, "Are you sure you want\nto delete this card?", "Delete", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    myManager.updateStorage(readCardInfo(), null);
                } else {
                    dispose();
                    new UserMenu(currentUser);
                }

            }
        }
    }


    private class Icon extends JPanel {

        Image img;

        public Icon() {
            try {
                img = ImageIO.read(new File("card.png"));
            } catch (IOException e) {
                e.fillInStackTrace();
            }
        }

        @Override
        public void paintComponent(Graphics G) {
            super.paintComponent(G);
            Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
            setPreferredSize(size);
            setMinimumSize(size);
            setMaximumSize(size);
            setSize(size);
            setLayout(null);
            G.drawImage(img, 0, 0, this.getWidth(), 505, null);
        }
    }

    private class UpperCaseFilter extends DocumentFilter {

        @Override
        public void insertString(DocumentFilter.FilterBypass fb, int offset, String text, AttributeSet attr) throws BadLocationException {
            fb.insertString(offset, text.toUpperCase(), attr);
        }

        @Override
        public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            fb.replace(offset, length, text.toUpperCase(), attrs);
        }
    }

    private CreditCard readCardInfo() {

        int i = type.getSelectedIndex();
        try {
            CreditCard card = new CreditCard(cardholder.getText(), cardTypes[i] , cardnumber.getText(), new UsefulDate(), Integer.parseInt(cvv.getText()));
            return card;
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }
        return null;
    }
}
