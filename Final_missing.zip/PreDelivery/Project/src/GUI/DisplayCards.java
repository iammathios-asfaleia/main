/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.CardManager;
import Utilities.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public final class DisplayCards extends JFrame {

    private CardManager myManager;
    private Container pane;
    private JButton type1,type2,back;
    private JLabel label;
    private JPanel buttonPanel,jp;
    private String typeChosen;

    public DisplayCards(CardManager myManager){
        super("Your Cards");
        this.myManager=myManager;
        jp = new JPanel();

        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        pane = getContentPane();
        type1 = new JButton("Visa");
        type2 = new JButton("MasterCard");
        back = new JButton("Back");
        label = new JLabel("Select card type");
        buttonPanel = new JPanel();

        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        label.setFont(new Font("ArialBlack", Font.BOLD, 24));
        label.setAlignmentX(CENTER_ALIGNMENT);
        label.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        pane.setBackground(Color.decode("#99d9ea"));
        buttonPanel.setBackground(Color.decode("#99d9ea"));
        type1.setFont(new Font("ArialBlack", 0, 16));
        type2.setFont(new Font("ArialBlack", 0, 16));
        back.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------

        type1.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { typeChosen="Visa"; cardTextArea(); validate();}});
        type2.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { typeChosen="MasterCard"; cardTextArea(); validate();}});
        back.addActionListener(new ActionListener() { public void actionPerformed(ActionEvent e) { dispose(); }});

        pane.add(label);
        buttonPanel.add(type1);
        buttonPanel.add(type2);
        buttonPanel.add(back);
        pane.add(buttonPanel);

        this.setVisible(true);
    }

    private void cardTextArea(){
        ArrayList <CreditCard> cardsList = myManager.displayCards(typeChosen);
        jp.removeAll();

        if(cardsList != null) {
            System.out.println(cardsList);

            jp.setBackground(Color.decode("#99d9ea"));
            JTextArea txtArea = new JTextArea();

            for (CreditCard card : cardsList) {
                txtArea.append(card.toString()+"\n");
            }
            jp.add(txtArea);
            this.pane.add(jp);
        }else JOptionPane.showMessageDialog(null,"You have no cards.");
    }

}
