/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.*;
import Utilities.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class UserMenu extends JFrame{

    private CardManager myManager;
    private User currentUser;
    
    public UserMenu(User currentUser) {
        super("Secure Credit Card Storage - Home");

        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        Container pane = getContentPane();
        //-------------------------------initial window setup-------------------








        //--------------------initializing attributes---------------------------
        JButton displayButton, addButton, logoutButton, updateButton, deleteButton;
        JLabel welcome=new JLabel("What would you like to do today " + currentUser.getUsername() + "?", JLabel.CENTER);
        displayButton=new JButton("Display All Cards");
        addButton=new JButton("Add Card");
        updateButton=new JButton("Edit Card");
        deleteButton=new JButton("Delete Card");
        logoutButton=new JButton("Logout");
        JPanel buttonPanel=new JPanel();
        myManager=new CardManager(currentUser);
        this.currentUser=currentUser;
        //--------------------initializing attributes---------------------------










        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        welcome.setFont(new Font("ArialBlack", Font.BOLD, 24));
        welcome.setAlignmentX(CENTER_ALIGNMENT);
        welcome.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        buttonPanel.setBackground(Color.decode("#99d9ea"));
        addButton.setFont(new Font("ArialBlack", 0, 16));
        displayButton.setFont(new Font("ArialBlack", 0, 16));
        updateButton.setFont(new Font("ArialBlack", 0, 16));
        deleteButton.setFont(new Font("ArialBlack", 0, 16));
        logoutButton.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------





        //----------------------functionality-----------------------------------
        displayButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){new DisplayCards(myManager);}});

        addButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ new CardWindow(1, currentUser,myManager);}});

        updateButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
            new CardWindow(2, currentUser, myManager);
            JOptionPane.showMessageDialog(null, "Insert the credentials of the card you want to edit.");
        }});

        deleteButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
            new CardWindow(3, currentUser,myManager);
            JOptionPane.showMessageDialog(null, "Insert the card credentials you want to delete.");
        }});

        logoutButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ logoutActions(); }});
        //----------------------functionality-----------------------------------




        //-------------------------add components-------------------------------
        buttonPanel.add(displayButton);
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(logoutButton);

        pane.add(Box.createVerticalGlue());//filler to separate from top of window
        pane.add(welcome);
        pane.add(buttonPanel);
        pane.add(Box.createVerticalGlue());//filler to separate from bottom of window
        //-------------------------add components-------------------------------


        setVisible(true);
    }

    private void logoutActions(){

        if(currentUser.isFirstTimeLogin()){AccountManager.register(currentUser);}

        IntegrityManager.getSignature(currentUser.getUsername(), false, myManager);

        dispose();
        new HomePage();

    }


}
