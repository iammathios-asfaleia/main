/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.KeyHandler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class HomePage extends JFrame {

    public HomePage(){
        super("Secure Credit Card Storage - Welcome");

        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        Container pane = getContentPane();
        KeyHandler.initializeAppKeys();
        //-------------------------------initial window setup-------------------





        //--------------------initializing attributes---------------------------
        JButton loginButton, registerButton, exitButton;
        JLabel welcome=new JLabel("Welcome to the world's safest place to store credit card data", JLabel.CENTER);
        loginButton=new JButton("Login");
        registerButton=new JButton("Register");
        exitButton=new JButton("Exit");
        JPanel buttonPanel=new JPanel();
        //--------------------initializing attributes---------------------------






        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        welcome.setFont(new Font("ArialBlack", Font.BOLD, 24));
        welcome.setAlignmentX(CENTER_ALIGNMENT);
        welcome.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        buttonPanel.setBackground(Color.decode("#99d9ea"));
        loginButton.setFont(new Font("ArialBlack", 0, 16));
        registerButton.setFont(new Font("ArialBlack", 0, 16));
        exitButton.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------





        //----------------------functionality-----------------------------------
        loginButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){dispose(); new LoginPage();}});
        registerButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ dispose(); new RegisterPage();}});
        exitButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){ System.exit(0);}});
        //----------------------functionality-----------------------------------







        //-------------------------add components-------------------------------
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(exitButton);

        pane.add(Box.createVerticalGlue());//filler to separate from top of window
        pane.add(welcome);
        pane.add(buttonPanel);
        pane.add(Box.createVerticalGlue());//filler to separate from bottom of window
        //-------------------------add components-------------------------------


        setVisible(true);


    }

}
