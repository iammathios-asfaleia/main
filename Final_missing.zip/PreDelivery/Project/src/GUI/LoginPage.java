/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package GUI;

import Managers.AccountManager;
import Managers.CardManager;
import Managers.IntegrityManager;
import Utilities.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class LoginPage extends JFrame {

    private JTextField passwordText, usernameText;
    private JLabel message;

    public LoginPage(){
        super("Aegean Posts - Authentication");


        //-------------------------------initial window setup-------------------
        //JFrame dimensions
        setSize(800, 500);
        //close window and program with "X" button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //start window on center of screen
        setLocationRelativeTo(null);
        //new container since JFrame is not a container
        Container pane=getContentPane();
        //-------------------------------initial window setup-------------------





        //--------------------initializing attributes---------------------------
        JPanel buttonPanel=new JPanel();
        JButton loginButton, backButton;
        loginButton=new JButton("Login", new ImageIcon("login.png"));
        backButton=new JButton("Back");
        this.message=new JLabel("Insert your credentials", JLabel.CENTER);
        JLabel usernameLabel=new JLabel("Username:");
        JLabel passwordLabel=new JLabel("Password:");
        JPanel usernameTextPanel=new JPanel();//used to avoid textfield expanding more than necessary
        JPanel passwordTextPanel=new JPanel();//same
        this.usernameText = new JTextField(20);
        this.passwordText = new JPasswordField(20);
        //--------------------initializing attributes---------------------------






        //------------------------------------aesthetics------------------------
        pane.setLayout(new BoxLayout(pane,BoxLayout.PAGE_AXIS));
        pane.setBackground(Color.decode("#99d9ea"));

        message.setFont(new Font("ArialBlack", Font.BOLD, 24));
        usernameLabel.setFont(new Font("ArialBlack", 0, 16));
        passwordLabel.setFont(new Font("ArialBlack", 0, 16));
        message.setAlignmentX(CENTER_ALIGNMENT);
        message.setBounds(0, 0, pane.getWidth()/4, pane.getWidth()/4);//set message position dynamic to its container


        usernameTextPanel.setBackground(Color.decode("#99d9ea"));
        passwordTextPanel.setBackground(Color.decode("#99d9ea"));
        buttonPanel.setBackground(Color.decode("#99d9ea"));
        loginButton.setFont(new Font("ArialBlack", 0, 16));
        backButton.setFont(new Font("ArialBlack", 0, 16));
        //------------------------------------aesthetics------------------------





        //----------------------functionality-----------------------------------
        loginButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {loginActions();}});

        backButton.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e) {dispose(); new HomePage();}});

        //hide error message if user tries to type again
        usernameText.addMouseListener(new MouseAdapter(){ public void mouseClicked(MouseEvent e){  message.setForeground(Color.BLACK);  message.setText("Insert your credentials");}});
        passwordText.addMouseListener(new MouseAdapter(){ public void mouseClicked(MouseEvent e){  message.setForeground(Color.BLACK);  message.setText("Insert your credentials");}});
        //----------------------functionality-----------------------------------




        //-------------------------add components-------------------------------
        buttonPanel.add(loginButton);
        buttonPanel.add(backButton);

        usernameTextPanel.add(usernameText);
        passwordTextPanel.add(passwordText);

        pane.add(Box.createVerticalGlue());//filler to separate from top of window
        pane.add(message);
        pane.add(Box.createGlue());//small empty space between previous and next component
        pane.add(usernameLabel);
        pane.add(usernameTextPanel);
        pane.add(passwordLabel);
        pane.add(passwordTextPanel);
        pane.add(buttonPanel);
        pane.add(Box.createVerticalGlue());//filler to separate from bottom of window
        //-------------------------add components-------------------------------


        setVisible(true);


    }

    private void loginActions(){
        if(usernameText.getText().equals("") || passwordText.getText().equals("")){
            message.setText("Please fill all fields before continuing");
            message.setForeground(Color.RED);
        }else{

            User currentUser=AccountManager.login(usernameText.getText(), passwordText.getText());

            if(currentUser!=null){

                if(!currentUser.isFirstTimeLogin()){integrityMechanism(currentUser);}

                dispose();
                new UserMenu(currentUser);

            }else{
                JOptionPane.showMessageDialog(null, "Login Failed!!","Failed",JOptionPane.ERROR_MESSAGE);
                message.setText("Login Failed");
                message.setForeground(Color.RED);
            }

        }
    }

    private void integrityMechanism(User currentUser){

        byte[] newSessionSignature= IntegrityManager.getSignature(currentUser.getUsername(), true, new CardManager(currentUser));
        JOptionPane.showMessageDialog(null, "Login Successful.");

        if(newSessionSignature!=null) {
            if (IntegrityManager.isEqual(currentUser.getUsername(), newSessionSignature)) {
                JOptionPane.showMessageDialog(null, "Your data is safe");
            } else {
                JOptionPane.showMessageDialog(null, "Your data has been tampered with");
            }
        }

    }

}
