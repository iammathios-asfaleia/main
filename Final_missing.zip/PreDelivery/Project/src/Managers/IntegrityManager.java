/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;

import Encryptions.*;
import Utilities.DoumasSuggestion;

import javax.crypto.SecretKey;
import java.io.*;
import java.nio.file.*;
import java.security.PrivateKey;
import java.util.*;

public final class IntegrityManager {

    private static byte[] integrityDigest(String username, CardManager manager){

        String digestOne="error";
        ArrayList<byte[]> storedCards=manager.readUnwrappedCards();
        byte[] finalDigest=null;
        File cardVault=new File("Users\\"+username+"\\cardVault.dat");

        if(cardVault.exists()){
            digestOne=DigestGenerator.integrityDigestOne(storedCards);

            if(!digestOne.equals("error")){
                finalDigest=DigestGenerator.getSHA3_256(username, digestOne);
            }
        }

        System.out.println(DigestGenerator.toHexString(finalDigest));

        return finalDigest;
    }

    public static byte[] getSignature(String username, boolean login, CardManager manager){

        Path cardsLocation=Paths.get("Users\\"+username+"\\cardVault.dat");
        byte[] encryptedSignature=null;

        if(Files.exists(cardsLocation)) {

            byte[] digest = integrityDigest(username, manager);

            PrivateKey appPrivate = KeyHandler.getAppPrivateKey();

            byte[] digitalSign = AsymmetricKeyFactory.encryptWithPrivate(digest, appPrivate);

            //read user's secret key from file (encrypted with app's public)
            byte[] encryptedSymmetricKey = KeyHandler.getUserEncryptedSecretKey(username);

            //decrypt user's secret key
            SecretKey usersKey = (SecretKey) AsymmetricKeyFactory.decryptWithPrivate(encryptedSymmetricKey, KeyHandler.getAppPrivateKey());

            encryptedSignature = SymmetricKeyFactory.encrypt(digitalSign, usersKey);

            if (!login) {
                storeToFile(username, encryptedSignature);
            }
        }

        return encryptedSignature;
    }

    private static void storeToFile(String username, byte[] signature){
        File signatureFile = new File("Users\\" + username + "\\Signature.dat");//user's subfolder + filename
        ObjectOutputStream output;
        DoumasSuggestion objectSignature=new DoumasSuggestion(signature);
        try{
            output=new ObjectOutputStream(new FileOutputStream(signatureFile));

            output.writeObject(objectSignature);
            output.flush();
            output.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static boolean isEqual(String username, byte[] newSignature){

        Path signatureLocation= Paths.get("Users\\" + username + "\\Signature.dat");
        File signatureFile = new File("Users\\" + username + "\\Signature.dat");//user's subfolder + filename

        ObjectInputStream ois;

        try{
            ois=new ObjectInputStream(new FileInputStream(signatureFile));

            if(Files.exists(signatureLocation)){
                DoumasSuggestion storedSignature=(DoumasSuggestion)ois.readObject();

                byte[] byteSignature=storedSignature.getByteArray();

                if(Arrays.equals(newSignature, byteSignature)){
                    System.out.println("Storing Signature to File");
                    return true;
                }
            }

            ois.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    }
}
