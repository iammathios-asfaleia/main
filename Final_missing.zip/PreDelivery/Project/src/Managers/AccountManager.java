/*
 * Icsd14130 Ματθαίος Μπεγκβάρφαϊ
 * Icsd14182 Γιάννης Σκενδέρης
 * Icsd14083 Διονύσης Κιόρντια
 */

package Managers;

import Encryptions.*;
import Utilities.*;

import javax.swing.*;
import java.io.*;
import java.nio.file.*;


public final class AccountManager {

    //=====================================REGISTER=============================================================//
    public static boolean register(User user) {
        Path path = Paths.get("Users\\" + user.getUsername()); // User personal folder path

        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path); // Create user personal folder
            } catch (IOException e) {
                //failed to create directory
                e.printStackTrace();
            }
        }

        File register_file = new File("Users\\" + user.getUsername() + "\\PersonalDetails"); // Create user personal file

        ObjectOutputStream Object_out = null;
        FileOutputStream File_out = null;

        try {
            // Check if the username exists into the file (if no->append->write) (if yes->system.out.println)
            if (checkUsernameExists(user.getUsername()) == false) {
                // Append file because header already written
                File_out = new FileOutputStream(register_file);
                Object_out = new ObjectOutputStream(File_out);

                Object_out.writeObject(user); // Write user to file

                return true;

            } else if(user.isFirstTimeLogin()){

                user.loginUpdate();

                try {
                    Files.deleteIfExists(Paths.get("Users\\" + user.getUsername() + "\\PersonalDetails"));
                } catch (IOException e) {
                    System.out.println();
                }

                File_out = new FileOutputStream(register_file);
                Object_out = new ObjectOutputStream(File_out);

                Object_out.writeObject(user); // Write user to file

                return true;
            }else {
                System.out.println(user.getUsername() + " Can't register!");
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (Object_out != null) {
                    Object_out.flush();
                    Object_out.close();
                    File_out.flush();
                    File_out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    //=====================================LOGIN=============================================================//
    public static User login(String username, String password) {

        boolean resultDigests = false;
        User user = null;

        if (Files.exists(Paths.get("Users\\" + username + "\\PersonalDetails"))) {
            try {
                ObjectInputStream objectIn = new ObjectInputStream(new FileInputStream("Users\\" + username + "\\PersonalDetails"));

                User tempUser = (User) objectIn.readObject();
                String tempUserDigest = tempUser.getDigest();
                String newLoginDigest = DigestGenerator.generateDigest(password, tempUser.getSalt());

                resultDigests = DigestGenerator.digestEquality(tempUserDigest, newLoginDigest);

                if (resultDigests) {
                    user = tempUser;
                }

            } catch (IOException e) {

                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Registration Failed!!\nYou must register first.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println((resultDigests ? "Welcome" : "You can't Login"));

        return user;
    }

    //=====================================CHECK_USERNAME_IF_EXISTS=============================================================//
    private static boolean checkUsernameExists(String username) {

        Path path = Paths.get("Users\\" + username + "\\PersonalDetails");

        if (Files.exists(path)) {
            return true;
        }

        return false;
    }

}
